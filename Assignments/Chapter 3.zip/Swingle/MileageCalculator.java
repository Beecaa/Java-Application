import java.util.Scanner;

public class MileageCalculator {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        int totalMiles = 0;
        int totalGallons = 0;

        while (true) {
            System.out.print("Enter miles driven (-1 to quit): ");
            int miles = input.nextInt();

            if (miles == -1) {
                break;
            }

            System.out.print("Enter gallons used: ");
            int gallons = input.nextInt();

            if (gallons == 0) {
                System.out.println("Gallons cannot be zero.");
                continue;
            }

            double mpg = (double) miles / gallons;
            System.out.printf("Miles per gallon for this trip: %.2f%n", mpg);

            totalMiles += miles;
            totalGallons += gallons;

            if (totalGallons != 0) {
                double combinedMpg = (double) totalMiles / totalGallons;
                System.out.printf("Combined miles per gallon so far: %.2f%n", combinedMpg);
            }
        }

        if (totalGallons != 0) {
            double finalMpg = (double) totalMiles / totalGallons;
            System.out.printf("Final combined miles per gallon: %.2f%n", finalMpg);
        } else {
            System.out.println("No trips were recorded.");
        }

        input.close();
    }
}